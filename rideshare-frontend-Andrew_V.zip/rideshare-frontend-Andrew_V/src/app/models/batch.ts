export class Batch {
    batchNumber: number;
    address: string;
}